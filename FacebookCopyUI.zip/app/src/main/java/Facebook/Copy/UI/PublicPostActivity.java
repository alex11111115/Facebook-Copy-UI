package Facebook.Copy.UI;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.vanniktech.emoji.*;
import com.vanniktech.emoji.facebook.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import android.text.InputFilter;
import android.text.Spanned;

public class PublicPostActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear98;
	private LinearLayout linear127;
	private EmojiEditText edittext1;
	private LinearLayout linear137;
	private ListView listview1;
	private CardView cardview1;
	private TextView textview1;
	private ImageView imageview1;
	private LinearLayout linear3;
	private TextView textview2;
	private LinearLayout linear128;
	private CircleImageView circleimageview1;
	private LinearLayout linear129;
	private LinearLayout linear130;
	private EmojiTextView textview72;
	private CardView cardview2;
	private LinearLayout linear135;
	private ImageView imageview3;
	private TextView textview73;
	private ImageView imageview2;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
EmojiManager.install(new FacebookEmojiProvider());
		setContentView(R.layout.public_post);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear98 = findViewById(R.id.linear98);
		linear127 = findViewById(R.id.linear127);
		edittext1 = findViewById(R.id.edittext1);
		linear137 = findViewById(R.id.linear137);
		listview1 = findViewById(R.id.listview1);
		cardview1 = findViewById(R.id.cardview1);
		textview1 = findViewById(R.id.textview1);
		imageview1 = findViewById(R.id.imageview1);
		linear3 = findViewById(R.id.linear3);
		textview2 = findViewById(R.id.textview2);
		linear128 = findViewById(R.id.linear128);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear129 = findViewById(R.id.linear129);
		linear130 = findViewById(R.id.linear130);
		textview72 = findViewById(R.id.textview72);
		cardview2 = findViewById(R.id.cardview2);
		linear135 = findViewById(R.id.linear135);
		imageview3 = findViewById(R.id.imageview3);
		textview73 = findViewById(R.id.textview73);
		imageview2 = findViewById(R.id.imageview2);
		
		edittext1.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				if (0 < _charSeq.length()) {
					textview2.setBackgroundColor(0xFF216FDB);
					textview2.setTextColor(0xFFFFFFFF);
				}
				else {
					textview2.setBackgroundColor(0xFFE5E6EB);
					textview2.setTextColor(0xFFC3C6CB);
				}
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
	}
	
	private void initializeLogic() {
		/*
final EmojiPopup emojiPopup = EmojiPopup.Builder.fromRootView(linear1).build(edittext1);
emojiPopup.toggle();
*/
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		_removeScollBar(listview1);
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("key", "add");
			list.add(_item);
		}
		
		listview1.setAdapter(new Listview1Adapter(list));
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.grid, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear98 = _view.findViewById(R.id.linear98);
			final LinearLayout linear99 = _view.findViewById(R.id.linear99);
			final LinearLayout linear100 = _view.findViewById(R.id.linear100);
			final LinearLayout linear101 = _view.findViewById(R.id.linear101);
			final LinearLayout linear102 = _view.findViewById(R.id.linear102);
			final LinearLayout linear103 = _view.findViewById(R.id.linear103);
			final LinearLayout linear104 = _view.findViewById(R.id.linear104);
			final LinearLayout linear105 = _view.findViewById(R.id.linear105);
			final LinearLayout linear106 = _view.findViewById(R.id.linear106);
			final LinearLayout linear107 = _view.findViewById(R.id.linear107);
			final LinearLayout linear108 = _view.findViewById(R.id.linear108);
			final LinearLayout linear109 = _view.findViewById(R.id.linear109);
			final LinearLayout linear110 = _view.findViewById(R.id.linear110);
			final LinearLayout linear111 = _view.findViewById(R.id.linear111);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final ImageView imageview6 = _view.findViewById(R.id.imageview6);
			final TextView textview7 = _view.findViewById(R.id.textview7);
			final ImageView imageview7 = _view.findViewById(R.id.imageview7);
			final TextView textview8 = _view.findViewById(R.id.textview8);
			final ImageView imageview8 = _view.findViewById(R.id.imageview8);
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}