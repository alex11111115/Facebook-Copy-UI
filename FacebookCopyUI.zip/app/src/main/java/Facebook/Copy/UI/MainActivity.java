package Facebook.Copy.UI;

import Facebook.Copy.UI.SplashActivity;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.vanniktech.emoji.*;
import com.vanniktech.emoji.facebook.*;
import de.hdodenhof.circleimageview.*;
import java.io.*;
import java.text.*;
import java.text.DecimalFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import androidx.core.widget.NestedScrollView;
import android.text.InputFilter;
import android.text.Spanned;

public class MainActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list3 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> video = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> notification = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear17;
	private LinearLayout main2;
	private ImageView imageview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private ImageView imageview3;
	private LinearLayout lin_mune_icon;
	private LinearLayout lin_notifications_icon;
	private LinearLayout lin_market_icon;
	private LinearLayout lin_profile_icon;
	private LinearLayout lin_frinds_icon;
	private LinearLayout lin_main_icon;
	private ImageView mune_icon;
	private LinearLayout lin_mune;
	private ImageView notifications_icon;
	private LinearLayout lin_notifications;
	private ImageView market_icon;
	private LinearLayout lin_market;
	private ImageView profile_icon;
	private LinearLayout lin_profile;
	private ImageView friends_icon;
	private LinearLayout lin_friend;
	private ImageView main_icon;
	private LinearLayout lin_main;
	private NestedScrollView vscroll1;
	private LinearLayout lin_frinds;
	private LinearLayout lin_prof;
	private ScrollView vscroll4;
	private ScrollView vscroll5;
	private ScrollView vscroll6;
	private LinearLayout linear20;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear26;
	private LinearLayout linear33;
	private RecyclerView recyclerview2;
	private ImageView imageview10;
	private CardView cardview1;
	private CircleImageView circleimageview1;
	private LinearLayout linear22;
	private TextView textview7;
	private LinearLayout linear35;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private TextView textview2;
	private ImageView imageview12;
	private TextView textview1;
	private ImageView imageview11;
	private TextView textview3;
	private ImageView imageview13;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private TextView textview6;
	private LinearLayout linear30;
	private TextView textview5;
	private LinearLayout linear32;
	private TextView textview4;
	private LinearLayout linear31;
	private RecyclerView recyclerview3;
	private LinearLayout linear47;
	private NestedScrollView vscroll2;
	private ImageView imageview14;
	private TextView textview8;
	private LinearLayout linear41;
	private LinearLayout linear48;
	private LinearLayout linear49;
	private LinearLayout linear50;
	private RecyclerView recyclerview4;
	private TextView textview9;
	private TextView textview10;
	private TextView textview13;
	private TextView textview12;
	private TextView textview11;
	private ScrollView vscroll3;
	private LinearLayout linear42;
	private LinearLayout linear52;
	private LinearLayout linear81;
	private LinearLayout linear82;
	private FrameLayout linear53;
	private LinearLayout linear54;
	private CircleImageView circleimageview2;
	private ImageView imageview17;
	private EmojiTextView textview15;
	private EmojiTextView textview14;
	private LinearLayout linear55;
	private LinearLayout linear59;
	private LinearLayout linear61;
	private TextView button1;
	private LinearLayout linear75;
	private LinearLayout linear76;
	private TextView textview39;
	private LinearLayout linear77;
	private TextView textview42;
	private CardView cardview2;
	private ImageView imageview16;
	private ImageView imageview15;
	private LinearLayout linear56;
	private LinearLayout linear57;
	private LinearLayout linear58;
	private ImageView imageview18;
	private TextView textview16;
	private ImageView imageview19;
	private TextView textview17;
	private ImageView imageview20;
	private LinearLayout linear60;
	private LinearLayout linear62;
	private LinearLayout linear63;
	private LinearLayout linear64;
	private LinearLayout linear65;
	private LinearLayout linear66;
	private LinearLayout linear67;
	private LinearLayout linear70;
	private LinearLayout linear71;
	private LinearLayout linear72;
	private TextView textview19;
	private TextView textview18;
	private ImageView imageview21;
	private TextView textview20;
	private ImageView imageview22;
	private TextView textview21;
	private TextView textview22;
	private ImageView imageview23;
	private TextView textview23;
	private TextView textview24;
	private ImageView imageview24;
	private TextView textview26;
	private ImageView imageview25;
	private TextView textview28;
	private ImageView imageview26;
	private TextView textview30;
	private ImageView imageview27;
	private TextView textview34;
	private ImageView imageview30;
	private TextView textview35;
	private ImageView imageview31;
	private TextView textview36;
	private ImageView imageview32;
	private TextView textview37;
	private TextView textview38;
	private LinearLayout linear79;
	private CardView cardview3;
	private LinearLayout linear80;
	private ImageView imageview33;
	private EmojiTextView textview40;
	private LinearLayout linear83;
	private LinearLayout linear84;
	private LinearLayout linear85;
	private LinearLayout linear86;
	private ImageView imageview34;
	private ImageView imageview35;
	private TextView textview43;
	private TextView textview44;
	private CircleImageView circleimageview3;
	private LinearLayout linear87;
	private LinearLayout linear88;
	private LinearLayout linear89;
	private LinearLayout linear90;
	private LinearLayout linear91;
	private TextView textview45;
	private ImageView imageview36;
	private TextView textview46;
	private ImageView imageview37;
	private TextView textview47;
	private ImageView imageview38;
	private LinearLayout linear43;
	private LinearLayout linear92;
	private LinearLayout linear93;
	private RecyclerView recyclerview5;
	private CardView cardview5;
	private CardView cardview4;
	private TextView textview48;
	private ImageView imageview39;
	private ImageView imageview40;
	private TextView textview49;
	private TextView textview50;
	private TextView textview51;
	private CardView cardview6;
	private TextView textview52;
	private LinearLayout linear45;
	private LinearLayout linear94;
	private RecyclerView recyclerview6;
	private CardView cardview9;
	private TextView textview53;
	private ImageView imageview43;
	private LinearLayout linear44;
	private LinearLayout linear95;
	private LinearLayout linear99;
	private LinearLayout linear98;
	private LinearLayout linear102;
	private LinearLayout linear103;
	private LinearLayout linear104;
	private LinearLayout linear108;
	private LinearLayout linear109;
	private CardView cardview19;
	private LinearLayout linear125;
	private LinearLayout linear126;
	private LinearLayout linear127;
	private LinearLayout linear128;
	private LinearLayout linear130;
	private LinearLayout linear131;
	private CardView cardview22;
	private CardView cardview11;
	private CardView cardview10;
	private LinearLayout linear96;
	private TextView textview54;
	private ImageView imageview45;
	private ImageView imageview44;
	private LinearLayout linear101;
	private CircleImageView circleimageview4;
	private TextView textview56;
	private TextView textview55;
	private TextView textview57;
	private ImageView imageview46;
	private LinearLayout linear105;
	private LinearLayout linear106;
	private LinearLayout linear107;
	private TextView textview58;
	private CircleImageView circleimageview5;
	private CardView cardview12;
	private ImageView imageview47;
	private TextView textview59;
	private TextView textview60;
	private LinearLayout linear111;
	private LinearLayout linear115;
	private LinearLayout linear118;
	private CardView cardview13;
	private CardView cardview14;
	private LinearLayout linear114;
	private ImageView imageview49;
	private TextView textview62;
	private LinearLayout linear113;
	private ImageView imageview48;
	private TextView textview61;
	private CardView cardview15;
	private CardView cardview16;
	private LinearLayout linear116;
	private ImageView imageview50;
	private TextView textview63;
	private LinearLayout linear117;
	private ImageView imageview51;
	private TextView textview64;
	private CardView cardview17;
	private CardView cardview18;
	private LinearLayout linear119;
	private ImageView imageview52;
	private TextView textview65;
	private LinearLayout linear120;
	private ImageView imageview53;
	private TextView textview66;
	private LinearLayout linear121;
	private TextView textview67;
	private ImageView imageview57;
	private TextView textview71;
	private ImageView imageview56;
	private LinearLayout linear133;
	private ImageView imageview58;
	private TextView textview72;
	private ImageView imageview59;
	private LinearLayout linear134;
	private ImageView imageview60;
	private TextView textview73;
	private ImageView imageview61;
	private LinearLayout linear132;
	private TextView textview70;
	
	private Intent post = new Intent();
	private Intent log = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
EmojiManager.install(new FacebookEmojiProvider());
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		linear17 = findViewById(R.id.linear17);
		main2 = findViewById(R.id.main2);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		imageview3 = findViewById(R.id.imageview3);
		lin_mune_icon = findViewById(R.id.lin_mune_icon);
		lin_notifications_icon = findViewById(R.id.lin_notifications_icon);
		lin_market_icon = findViewById(R.id.lin_market_icon);
		lin_profile_icon = findViewById(R.id.lin_profile_icon);
		lin_frinds_icon = findViewById(R.id.lin_frinds_icon);
		lin_main_icon = findViewById(R.id.lin_main_icon);
		mune_icon = findViewById(R.id.mune_icon);
		lin_mune = findViewById(R.id.lin_mune);
		notifications_icon = findViewById(R.id.notifications_icon);
		lin_notifications = findViewById(R.id.lin_notifications);
		market_icon = findViewById(R.id.market_icon);
		lin_market = findViewById(R.id.lin_market);
		profile_icon = findViewById(R.id.profile_icon);
		lin_profile = findViewById(R.id.lin_profile);
		friends_icon = findViewById(R.id.friends_icon);
		lin_friend = findViewById(R.id.lin_friend);
		main_icon = findViewById(R.id.main_icon);
		lin_main = findViewById(R.id.lin_main);
		vscroll1 = findViewById(R.id.vscroll1);
		lin_frinds = findViewById(R.id.lin_frinds);
		lin_prof = findViewById(R.id.lin_prof);
		vscroll4 = findViewById(R.id.vscroll4);
		vscroll5 = findViewById(R.id.vscroll5);
		vscroll6 = findViewById(R.id.vscroll6);
		linear20 = findViewById(R.id.linear20);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear26 = findViewById(R.id.linear26);
		linear33 = findViewById(R.id.linear33);
		recyclerview2 = findViewById(R.id.recyclerview2);
		imageview10 = findViewById(R.id.imageview10);
		cardview1 = findViewById(R.id.cardview1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear22 = findViewById(R.id.linear22);
		textview7 = findViewById(R.id.textview7);
		linear35 = findViewById(R.id.linear35);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		textview2 = findViewById(R.id.textview2);
		imageview12 = findViewById(R.id.imageview12);
		textview1 = findViewById(R.id.textview1);
		imageview11 = findViewById(R.id.imageview11);
		textview3 = findViewById(R.id.textview3);
		imageview13 = findViewById(R.id.imageview13);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		linear29 = findViewById(R.id.linear29);
		textview6 = findViewById(R.id.textview6);
		linear30 = findViewById(R.id.linear30);
		textview5 = findViewById(R.id.textview5);
		linear32 = findViewById(R.id.linear32);
		textview4 = findViewById(R.id.textview4);
		linear31 = findViewById(R.id.linear31);
		recyclerview3 = findViewById(R.id.recyclerview3);
		linear47 = findViewById(R.id.linear47);
		vscroll2 = findViewById(R.id.vscroll2);
		imageview14 = findViewById(R.id.imageview14);
		textview8 = findViewById(R.id.textview8);
		linear41 = findViewById(R.id.linear41);
		linear48 = findViewById(R.id.linear48);
		linear49 = findViewById(R.id.linear49);
		linear50 = findViewById(R.id.linear50);
		recyclerview4 = findViewById(R.id.recyclerview4);
		textview9 = findViewById(R.id.textview9);
		textview10 = findViewById(R.id.textview10);
		textview13 = findViewById(R.id.textview13);
		textview12 = findViewById(R.id.textview12);
		textview11 = findViewById(R.id.textview11);
		vscroll3 = findViewById(R.id.vscroll3);
		linear42 = findViewById(R.id.linear42);
		linear52 = findViewById(R.id.linear52);
		linear81 = findViewById(R.id.linear81);
		linear82 = findViewById(R.id.linear82);
		linear53 = findViewById(R.id.linear53);
		linear54 = findViewById(R.id.linear54);
		circleimageview2 = findViewById(R.id.circleimageview2);
		imageview17 = findViewById(R.id.imageview17);
		textview15 = findViewById(R.id.textview15);
		textview14 = findViewById(R.id.textview14);
		linear55 = findViewById(R.id.linear55);
		linear59 = findViewById(R.id.linear59);
		linear61 = findViewById(R.id.linear61);
		button1 = findViewById(R.id.button1);
		linear75 = findViewById(R.id.linear75);
		linear76 = findViewById(R.id.linear76);
		textview39 = findViewById(R.id.textview39);
		linear77 = findViewById(R.id.linear77);
		textview42 = findViewById(R.id.textview42);
		cardview2 = findViewById(R.id.cardview2);
		imageview16 = findViewById(R.id.imageview16);
		imageview15 = findViewById(R.id.imageview15);
		linear56 = findViewById(R.id.linear56);
		linear57 = findViewById(R.id.linear57);
		linear58 = findViewById(R.id.linear58);
		imageview18 = findViewById(R.id.imageview18);
		textview16 = findViewById(R.id.textview16);
		imageview19 = findViewById(R.id.imageview19);
		textview17 = findViewById(R.id.textview17);
		imageview20 = findViewById(R.id.imageview20);
		linear60 = findViewById(R.id.linear60);
		linear62 = findViewById(R.id.linear62);
		linear63 = findViewById(R.id.linear63);
		linear64 = findViewById(R.id.linear64);
		linear65 = findViewById(R.id.linear65);
		linear66 = findViewById(R.id.linear66);
		linear67 = findViewById(R.id.linear67);
		linear70 = findViewById(R.id.linear70);
		linear71 = findViewById(R.id.linear71);
		linear72 = findViewById(R.id.linear72);
		textview19 = findViewById(R.id.textview19);
		textview18 = findViewById(R.id.textview18);
		imageview21 = findViewById(R.id.imageview21);
		textview20 = findViewById(R.id.textview20);
		imageview22 = findViewById(R.id.imageview22);
		textview21 = findViewById(R.id.textview21);
		textview22 = findViewById(R.id.textview22);
		imageview23 = findViewById(R.id.imageview23);
		textview23 = findViewById(R.id.textview23);
		textview24 = findViewById(R.id.textview24);
		imageview24 = findViewById(R.id.imageview24);
		textview26 = findViewById(R.id.textview26);
		imageview25 = findViewById(R.id.imageview25);
		textview28 = findViewById(R.id.textview28);
		imageview26 = findViewById(R.id.imageview26);
		textview30 = findViewById(R.id.textview30);
		imageview27 = findViewById(R.id.imageview27);
		textview34 = findViewById(R.id.textview34);
		imageview30 = findViewById(R.id.imageview30);
		textview35 = findViewById(R.id.textview35);
		imageview31 = findViewById(R.id.imageview31);
		textview36 = findViewById(R.id.textview36);
		imageview32 = findViewById(R.id.imageview32);
		textview37 = findViewById(R.id.textview37);
		textview38 = findViewById(R.id.textview38);
		linear79 = findViewById(R.id.linear79);
		cardview3 = findViewById(R.id.cardview3);
		linear80 = findViewById(R.id.linear80);
		imageview33 = findViewById(R.id.imageview33);
		textview40 = findViewById(R.id.textview40);
		linear83 = findViewById(R.id.linear83);
		linear84 = findViewById(R.id.linear84);
		linear85 = findViewById(R.id.linear85);
		linear86 = findViewById(R.id.linear86);
		imageview34 = findViewById(R.id.imageview34);
		imageview35 = findViewById(R.id.imageview35);
		textview43 = findViewById(R.id.textview43);
		textview44 = findViewById(R.id.textview44);
		circleimageview3 = findViewById(R.id.circleimageview3);
		linear87 = findViewById(R.id.linear87);
		linear88 = findViewById(R.id.linear88);
		linear89 = findViewById(R.id.linear89);
		linear90 = findViewById(R.id.linear90);
		linear91 = findViewById(R.id.linear91);
		textview45 = findViewById(R.id.textview45);
		imageview36 = findViewById(R.id.imageview36);
		textview46 = findViewById(R.id.textview46);
		imageview37 = findViewById(R.id.imageview37);
		textview47 = findViewById(R.id.textview47);
		imageview38 = findViewById(R.id.imageview38);
		linear43 = findViewById(R.id.linear43);
		linear92 = findViewById(R.id.linear92);
		linear93 = findViewById(R.id.linear93);
		recyclerview5 = findViewById(R.id.recyclerview5);
		cardview5 = findViewById(R.id.cardview5);
		cardview4 = findViewById(R.id.cardview4);
		textview48 = findViewById(R.id.textview48);
		imageview39 = findViewById(R.id.imageview39);
		imageview40 = findViewById(R.id.imageview40);
		textview49 = findViewById(R.id.textview49);
		textview50 = findViewById(R.id.textview50);
		textview51 = findViewById(R.id.textview51);
		cardview6 = findViewById(R.id.cardview6);
		textview52 = findViewById(R.id.textview52);
		linear45 = findViewById(R.id.linear45);
		linear94 = findViewById(R.id.linear94);
		recyclerview6 = findViewById(R.id.recyclerview6);
		cardview9 = findViewById(R.id.cardview9);
		textview53 = findViewById(R.id.textview53);
		imageview43 = findViewById(R.id.imageview43);
		linear44 = findViewById(R.id.linear44);
		linear95 = findViewById(R.id.linear95);
		linear99 = findViewById(R.id.linear99);
		linear98 = findViewById(R.id.linear98);
		linear102 = findViewById(R.id.linear102);
		linear103 = findViewById(R.id.linear103);
		linear104 = findViewById(R.id.linear104);
		linear108 = findViewById(R.id.linear108);
		linear109 = findViewById(R.id.linear109);
		cardview19 = findViewById(R.id.cardview19);
		linear125 = findViewById(R.id.linear125);
		linear126 = findViewById(R.id.linear126);
		linear127 = findViewById(R.id.linear127);
		linear128 = findViewById(R.id.linear128);
		linear130 = findViewById(R.id.linear130);
		linear131 = findViewById(R.id.linear131);
		cardview22 = findViewById(R.id.cardview22);
		cardview11 = findViewById(R.id.cardview11);
		cardview10 = findViewById(R.id.cardview10);
		linear96 = findViewById(R.id.linear96);
		textview54 = findViewById(R.id.textview54);
		imageview45 = findViewById(R.id.imageview45);
		imageview44 = findViewById(R.id.imageview44);
		linear101 = findViewById(R.id.linear101);
		circleimageview4 = findViewById(R.id.circleimageview4);
		textview56 = findViewById(R.id.textview56);
		textview55 = findViewById(R.id.textview55);
		textview57 = findViewById(R.id.textview57);
		imageview46 = findViewById(R.id.imageview46);
		linear105 = findViewById(R.id.linear105);
		linear106 = findViewById(R.id.linear106);
		linear107 = findViewById(R.id.linear107);
		textview58 = findViewById(R.id.textview58);
		circleimageview5 = findViewById(R.id.circleimageview5);
		cardview12 = findViewById(R.id.cardview12);
		imageview47 = findViewById(R.id.imageview47);
		textview59 = findViewById(R.id.textview59);
		textview60 = findViewById(R.id.textview60);
		linear111 = findViewById(R.id.linear111);
		linear115 = findViewById(R.id.linear115);
		linear118 = findViewById(R.id.linear118);
		cardview13 = findViewById(R.id.cardview13);
		cardview14 = findViewById(R.id.cardview14);
		linear114 = findViewById(R.id.linear114);
		imageview49 = findViewById(R.id.imageview49);
		textview62 = findViewById(R.id.textview62);
		linear113 = findViewById(R.id.linear113);
		imageview48 = findViewById(R.id.imageview48);
		textview61 = findViewById(R.id.textview61);
		cardview15 = findViewById(R.id.cardview15);
		cardview16 = findViewById(R.id.cardview16);
		linear116 = findViewById(R.id.linear116);
		imageview50 = findViewById(R.id.imageview50);
		textview63 = findViewById(R.id.textview63);
		linear117 = findViewById(R.id.linear117);
		imageview51 = findViewById(R.id.imageview51);
		textview64 = findViewById(R.id.textview64);
		cardview17 = findViewById(R.id.cardview17);
		cardview18 = findViewById(R.id.cardview18);
		linear119 = findViewById(R.id.linear119);
		imageview52 = findViewById(R.id.imageview52);
		textview65 = findViewById(R.id.textview65);
		linear120 = findViewById(R.id.linear120);
		imageview53 = findViewById(R.id.imageview53);
		textview66 = findViewById(R.id.textview66);
		linear121 = findViewById(R.id.linear121);
		textview67 = findViewById(R.id.textview67);
		imageview57 = findViewById(R.id.imageview57);
		textview71 = findViewById(R.id.textview71);
		imageview56 = findViewById(R.id.imageview56);
		linear133 = findViewById(R.id.linear133);
		imageview58 = findViewById(R.id.imageview58);
		textview72 = findViewById(R.id.textview72);
		imageview59 = findViewById(R.id.imageview59);
		linear134 = findViewById(R.id.linear134);
		imageview60 = findViewById(R.id.imageview60);
		textview73 = findViewById(R.id.textview73);
		imageview61 = findViewById(R.id.imageview61);
		linear132 = findViewById(R.id.linear132);
		textview70 = findViewById(R.id.textview70);
		
		lin_mune_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vscroll1.setVisibility(View.GONE);
				lin_frinds.setVisibility(View.GONE);
				lin_prof.setVisibility(View.GONE);
				vscroll4.setVisibility(View.GONE);
				vscroll5.setVisibility(View.GONE);
				vscroll6.setVisibility(View.VISIBLE);
				linear2.setVisibility(View.GONE);
				main_icon.setImageResource(R.drawable.facebook_icons3_97);
				friends_icon.setImageResource(R.drawable.facebook_icons3_63);
				profile_icon.setImageResource(R.drawable.icons_facebook2_228);
				market_icon.setImageResource(R.drawable.facebook_icons3_29);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				lin_main.setBackgroundColor(Color.TRANSPARENT);
				lin_friend.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(Color.TRANSPARENT);
				lin_market.setBackgroundColor(Color.TRANSPARENT);
				lin_notifications.setBackgroundColor(Color.TRANSPARENT);
				lin_mune.setBackgroundColor(0xFF1877F2);
				friends_icon.setColorFilter(0xFF727376);
				main_icon.setColorFilter(0xFF727376);
				profile_icon.setColorFilter(0xFF727376);
				market_icon.setColorFilter(0xFF727376);
				notifications_icon.setColorFilter(0xFF727376);
				mune_icon.setColorFilter(0xFF1877F2);
			}
		});
		
		lin_notifications_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vscroll1.setVisibility(View.GONE);
				lin_frinds.setVisibility(View.GONE);
				lin_prof.setVisibility(View.GONE);
				vscroll4.setVisibility(View.GONE);
				vscroll5.setVisibility(View.VISIBLE);
				vscroll6.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				main_icon.setImageResource(R.drawable.facebook_icons3_97);
				friends_icon.setImageResource(R.drawable.facebook_icons3_63);
				profile_icon.setImageResource(R.drawable.icons_facebook2_228);
				market_icon.setImageResource(R.drawable.facebook_icons3_29);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_137);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				lin_main.setBackgroundColor(Color.TRANSPARENT);
				lin_friend.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(Color.TRANSPARENT);
				lin_market.setBackgroundColor(Color.TRANSPARENT);
				lin_notifications.setBackgroundColor(0xFF1877F2);
				lin_mune.setBackgroundColor(Color.TRANSPARENT);
				friends_icon.setColorFilter(0xFF727376);
				main_icon.setColorFilter(0xFF727376);
				profile_icon.setColorFilter(0xFF727376);
				market_icon.setColorFilter(0xFF727376);
				notifications_icon.setColorFilter(0xFF1877F2);
				mune_icon.setColorFilter(0xFF727376);
			}
		});
		
		lin_market_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vscroll1.setVisibility(View.GONE);
				lin_frinds.setVisibility(View.GONE);
				lin_prof.setVisibility(View.GONE);
				vscroll4.setVisibility(View.VISIBLE);
				vscroll5.setVisibility(View.GONE);
				vscroll6.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				main_icon.setImageResource(R.drawable.facebook_icons3_97);
				friends_icon.setImageResource(R.drawable.facebook_icons3_63);
				profile_icon.setImageResource(R.drawable.icons_facebook2_228);
				market_icon.setImageResource(R.drawable.facebook_icons3_143);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				lin_main.setBackgroundColor(Color.TRANSPARENT);
				lin_friend.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(Color.TRANSPARENT);
				lin_market.setBackgroundColor(0xFF1877F2);
				lin_notifications.setBackgroundColor(Color.TRANSPARENT);
				lin_mune.setBackgroundColor(Color.TRANSPARENT);
				friends_icon.setColorFilter(0xFF727376);
				main_icon.setColorFilter(0xFF727376);
				profile_icon.setColorFilter(0xFF727376);
				market_icon.setColorFilter(0xFF1877F2);
				notifications_icon.setColorFilter(0xFF727376);
				mune_icon.setColorFilter(0xFF727376);
			}
		});
		
		lin_profile_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				vscroll1.setVisibility(View.GONE);
				lin_frinds.setVisibility(View.GONE);
				lin_prof.setVisibility(View.VISIBLE);
				vscroll4.setVisibility(View.GONE);
				vscroll5.setVisibility(View.GONE);
				vscroll6.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				main_icon.setImageResource(R.drawable.facebook_icons3_97);
				friends_icon.setImageResource(R.drawable.facebook_icons3_63);
				profile_icon.setImageResource(R.drawable.facebook_icons3_24);
				market_icon.setImageResource(R.drawable.facebook_icons3_29);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				lin_main.setBackgroundColor(Color.TRANSPARENT);
				lin_friend.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(0xFF1877F2);
				lin_market.setBackgroundColor(Color.TRANSPARENT);
				lin_notifications.setBackgroundColor(Color.TRANSPARENT);
				lin_mune.setBackgroundColor(Color.TRANSPARENT);
				friends_icon.setColorFilter(0xFF727376);
				main_icon.setColorFilter(0xFF727376);
				profile_icon.setColorFilter(0xFF1877F2);
				market_icon.setColorFilter(0xFF727376);
				notifications_icon.setColorFilter(0xFF727376);
				mune_icon.setColorFilter(0xFF727376);
			}
		});
		
		lin_frinds_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				friends_icon.setColorFilter(0xFF1877F2);
				main_icon.setColorFilter(0xFF727376);
				profile_icon.setColorFilter(0xFF727376);
				market_icon.setColorFilter(0xFF727376);
				notifications_icon.setColorFilter(0xFF727376);
				mune_icon.setColorFilter(0xFF727376);
				friends_icon.setImageResource(R.drawable.facebook_icons3_110);
				main_icon.setImageResource(R.drawable.facebook_icons3_97);
				profile_icon.setImageResource(R.drawable.icons_facebook2_228);
				market_icon.setImageResource(R.drawable.facebook_icons3_29);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				vscroll1.setVisibility(View.GONE);
				lin_frinds.setVisibility(View.VISIBLE);
				lin_prof.setVisibility(View.GONE);
				vscroll4.setVisibility(View.GONE);
				vscroll5.setVisibility(View.GONE);
				vscroll6.setVisibility(View.GONE);
				linear2.setVisibility(View.GONE);
				lin_friend.setBackgroundColor(0xFF1877F2);
				lin_main.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(Color.TRANSPARENT);
				lin_market.setBackgroundColor(Color.TRANSPARENT);
				lin_notifications.setBackgroundColor(Color.TRANSPARENT);
				lin_mune.setBackgroundColor(Color.TRANSPARENT);
			}
		});
		
		lin_main_icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				friends_icon.setColorFilter(0xFF727376);
				main_icon.setColorFilter(0xFF1877F2);
				profile_icon.setColorFilter(0xFF727376);
				market_icon.setColorFilter(0xFF727376);
				notifications_icon.setColorFilter(0xFF727376);
				mune_icon.setColorFilter(0xFF727376);
				friends_icon.setImageResource(R.drawable.facebook_icons3_63);
				main_icon.setImageResource(R.drawable.facebook_icons3_86);
				profile_icon.setImageResource(R.drawable.icons_facebook2_228);
				market_icon.setImageResource(R.drawable.facebook_icons3_29);
				notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
				mune_icon.setImageResource(R.drawable.icons_facebook2_190);
				vscroll1.setVisibility(View.VISIBLE);
				lin_frinds.setVisibility(View.GONE);
				lin_prof.setVisibility(View.GONE);
				vscroll4.setVisibility(View.GONE);
				vscroll5.setVisibility(View.GONE);
				vscroll6.setVisibility(View.GONE);
				linear2.setVisibility(View.VISIBLE);
				lin_main.setBackgroundColor(0xFF1877F2);
				lin_friend.setBackgroundColor(Color.TRANSPARENT);
				lin_profile.setBackgroundColor(Color.TRANSPARENT);
				lin_market.setBackgroundColor(Color.TRANSPARENT);
				lin_notifications.setBackgroundColor(Color.TRANSPARENT);
				lin_mune.setBackgroundColor(Color.TRANSPARENT);
			}
		});
		
		linear22.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				post.setClass(getApplicationContext(), PublicPostActivity.class);
				startActivity(post);
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		recyclerview5.addOnScrollListener(new RecyclerView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(RecyclerView recyclerView, int _scrollState) {
				super.onScrollStateChanged(recyclerView, _scrollState);
				
			}
			
			@Override
			public void onScrolled(RecyclerView recyclerView, int _offsetX, int _offsetY) {
				super.onScrolled(recyclerView, _offsetX, _offsetY);
				
			}
		});
		
		textview70.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				log.setClass(getApplicationContext(), LogActivity.class);
				startActivity(log);
			}
		});
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =MainActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
		}
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		imageview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		imageview14.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		imageview17.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		imageview16.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		textview9.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		textview10.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFE5E6EB));
		linear56.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
		linear57.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
		linear58.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFF1877F2));
		button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE7F3FF));
		textview42.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
		imageview34.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
		imageview35.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
		for(int _repeat23 = 0; _repeat23 < (int)(20); _repeat23++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "story number".concat(String.valueOf(list.size())));
				list.add(_item);
			}
			
		}
		recyclerview3.setAdapter(new Recyclerview3Adapter(list));
		recyclerview3.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		for(int _repeat28 = 0; _repeat28 < (int)(20); _repeat28++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "post number".concat(String.valueOf(list2.size())));
				list2.add(_item);
			}
			
		}
		recyclerview2.setAdapter(new Recyclerview2Adapter(list2));
		recyclerview2.setLayoutManager(new LinearLayoutManager(this));
		for(int _repeat44 = 0; _repeat44 < (int)(20); _repeat44++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "friend number".concat(String.valueOf(list3.size())));
				list3.add(_item);
			}
			
		}
		recyclerview4.setAdapter(new Recyclerview4Adapter(list3));
		recyclerview4.setLayoutManager(new LinearLayoutManager(this));
		for(int _repeat100 = 0; _repeat100 < (int)(20); _repeat100++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "not number".concat(String.valueOf(notification.size())));
				notification.add(_item);
			}
			
		}
		recyclerview6.setAdapter(new Recyclerview6Adapter(notification));
		recyclerview6.setLayoutManager(new LinearLayoutManager(this));
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("key1", "shogl.mp4");
			video.add(_item);
		}
		
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("key2", "leah.mp4");
			video.add(_item);
		}
		
		recyclerview5.setAdapter(new Recyclerview5Adapter(video));
		recyclerview5.setLayoutManager(new LinearLayoutManager(this));
		friends_icon.setColorFilter(0xFF727376);
		main_icon.setColorFilter(0xFF1877F2);
		profile_icon.setColorFilter(0xFF727376);
		market_icon.setColorFilter(0xFF727376);
		notifications_icon.setColorFilter(0xFF727376);
		mune_icon.setColorFilter(0xFF727376);
		friends_icon.setImageResource(R.drawable.facebook_icons3_63);
		main_icon.setImageResource(R.drawable.facebook_icons3_86);
		profile_icon.setImageResource(R.drawable.icons_facebook2_228);
		market_icon.setImageResource(R.drawable.facebook_icons3_29);
		notifications_icon.setImageResource(R.drawable.facebook_icons3_124);
		mune_icon.setImageResource(R.drawable.icons_facebook2_190);
		vscroll1.setVisibility(View.VISIBLE);
		lin_frinds.setVisibility(View.GONE);
		lin_prof.setVisibility(View.GONE);
		vscroll4.setVisibility(View.GONE);
		vscroll5.setVisibility(View.GONE);
		vscroll6.setVisibility(View.GONE);
		lin_main.setBackgroundColor(0xFF1877F2);
		lin_friend.setBackgroundColor(Color.TRANSPARENT);
		lin_profile.setBackgroundColor(Color.TRANSPARENT);
		lin_market.setBackgroundColor(Color.TRANSPARENT);
		lin_notifications.setBackgroundColor(Color.TRANSPARENT);
		lin_mune.setBackgroundColor(Color.TRANSPARENT);
		circleimageview2.setZ(100);
		imageview17.setZ(100);
		circleimageview5.setZ(100);
		_removeScollBar(vscroll1);
		_removeScollBar(vscroll2);
		_removeScollBar(vscroll3);
		_removeScollBar(vscroll4);
		_removeScollBar(vscroll5);
		_removeScollBar(vscroll6);
		_rippleRoundStroke(linear114, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear113, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear116, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear117, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear119, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear120, "#ffffff", "#e4e4e4", 0, 0, "#e0e0e0");
		_rippleRoundStroke(linear22, "#ffffff", "#e4e4e4", 50, 2, "#e0e0e0");
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cus_post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout linear28 = _view.findViewById(R.id.linear28);
			final LinearLayout linear18 = _view.findViewById(R.id.linear18);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview18 = _view.findViewById(R.id.textview18);
			final com.vanniktech.emoji.EmojiTextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear10 = _view.findViewById(R.id.linear10);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final LinearLayout linear14 = _view.findViewById(R.id.linear14);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final LinearLayout linear17 = _view.findViewById(R.id.linear17);
			final com.vanniktech.emoji.EmojiTextView textview4 = _view.findViewById(R.id.textview4);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			final TextView textview10 = _view.findViewById(R.id.textview10);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final ImageView imageview6 = _view.findViewById(R.id.imageview6);
			final ImageView imageview7 = _view.findViewById(R.id.imageview7);
			final LinearLayout linear19 = _view.findViewById(R.id.linear19);
			final LinearLayout linear20 = _view.findViewById(R.id.linear20);
			final LinearLayout linear21 = _view.findViewById(R.id.linear21);
			final TextView textview9 = _view.findViewById(R.id.textview9);
			final ImageView imageview10 = _view.findViewById(R.id.imageview10);
			final TextView textview8 = _view.findViewById(R.id.textview8);
			final ImageView imageview9 = _view.findViewById(R.id.imageview9);
			final TextView textview7 = _view.findViewById(R.id.textview7);
			final ImageView imageview8 = _view.findViewById(R.id.imageview8);
			final LinearLayout linear22 = _view.findViewById(R.id.linear22);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview2 = _view.findViewById(R.id.circleimageview2);
			final LinearLayout linear23 = _view.findViewById(R.id.linear23);
			final LinearLayout linear24 = _view.findViewById(R.id.linear24);
			final LinearLayout linear25 = _view.findViewById(R.id.linear25);
			final com.vanniktech.emoji.EmojiTextView textview12 = _view.findViewById(R.id.textview12);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final TextView textview11 = _view.findViewById(R.id.textview11);
			final ImageView imageview11 = _view.findViewById(R.id.imageview11);
			final TextView textview16 = _view.findViewById(R.id.textview16);
			final LinearLayout linear27 = _view.findViewById(R.id.linear27);
			final TextView textview15 = _view.findViewById(R.id.textview15);
			final TextView textview13 = _view.findViewById(R.id.textview13);
			final TextView textview14 = _view.findViewById(R.id.textview14);
			final LinearLayout linear29 = _view.findViewById(R.id.linear29);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview4 = _view.findViewById(R.id.circleimageview4);
			final LinearLayout linear30 = _view.findViewById(R.id.linear30);
			final LinearLayout linear31 = _view.findViewById(R.id.linear31);
			final LinearLayout linear32 = _view.findViewById(R.id.linear32);
			final com.vanniktech.emoji.EmojiTextView textview19 = _view.findViewById(R.id.textview19);
			final ImageView imageview16 = _view.findViewById(R.id.imageview16);
			final TextView textview20 = _view.findViewById(R.id.textview20);
			final ImageView imageview17 = _view.findViewById(R.id.imageview17);
			final TextView textview21 = _view.findViewById(R.id.textview21);
			final LinearLayout linear33 = _view.findViewById(R.id.linear33);
			final TextView textview22 = _view.findViewById(R.id.textview22);
			final TextView textview23 = _view.findViewById(R.id.textview23);
			final TextView textview24 = _view.findViewById(R.id.textview24);
			final LinearLayout linear26 = _view.findViewById(R.id.linear26);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview3 = _view.findViewById(R.id.circleimageview3);
			final ImageView imageview15 = _view.findViewById(R.id.imageview15);
			final ImageView imageview14 = _view.findViewById(R.id.imageview14);
			final ImageView imageview13 = _view.findViewById(R.id.imageview13);
			final TextView textview17 = _view.findViewById(R.id.textview17);
			
			linear23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF1F2F6));
			linear30.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF1F2F6));
			linear26.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFFF1F2F6));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview3Adapter extends RecyclerView.Adapter<Recyclerview3Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cus_story, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView your_story = _view.findViewById(R.id.your_story);
			final androidx.cardview.widget.CardView other_story = _view.findViewById(R.id.other_story);
			final RelativeLayout s1 = _view.findViewById(R.id.s1);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final ImageView add = _view.findViewById(R.id.add);
			final LinearLayout linear51 = _view.findViewById(R.id.linear51);
			final TextView textview28 = _view.findViewById(R.id.textview28);
			final RelativeLayout s2 = _view.findViewById(R.id.s2);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			final de.hdodenhof.circleimageview.CircleImageView c1 = _view.findViewById(R.id.c1);
			final LinearLayout linear52 = _view.findViewById(R.id.linear52);
			final TextView textview29 = _view.findViewById(R.id.textview29);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			if (_position == 0) {
				your_story.setVisibility(View.VISIBLE);
				other_story.setVisibility(View.GONE);
			}
			else {
				your_story.setVisibility(View.GONE);
				other_story.setVisibility(View.VISIBLE);
			}
			add.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF1877F2));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview4Adapter extends RecyclerView.Adapter<Recyclerview4Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview4Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.friends, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear51 = _view.findViewById(R.id.linear51);
			final LinearLayout linear52 = _view.findViewById(R.id.linear52);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview2 = _view.findViewById(R.id.circleimageview2);
			final LinearLayout linear53 = _view.findViewById(R.id.linear53);
			final LinearLayout linear54 = _view.findViewById(R.id.linear54);
			final TextView textview14 = _view.findViewById(R.id.textview14);
			final com.vanniktech.emoji.EmojiTextView textview15 = _view.findViewById(R.id.textview15);
			final Button button1 = _view.findViewById(R.id.button1);
			final Button button2 = _view.findViewById(R.id.button2);
			
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFFE5E6EB));
			button2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)12, 0xFF1877F2));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview5Adapter extends RecyclerView.Adapter<Recyclerview5Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview5Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.video, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview18 = _view.findViewById(R.id.textview18);
			final com.vanniktech.emoji.EmojiTextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear10 = _view.findViewById(R.id.linear10);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final LinearLayout linear14 = _view.findViewById(R.id.linear14);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final com.vanniktech.emoji.EmojiTextView textview4 = _view.findViewById(R.id.textview4);
			final FrameLayout linear34 = _view.findViewById(R.id.linear34);
			final LinearLayout video = _view.findViewById(R.id.video);
			final ImageView imageview12 = _view.findViewById(R.id.imageview12);
			final ImageView imageview11 = _view.findViewById(R.id.imageview11);
			final TextView textview25 = _view.findViewById(R.id.textview25);
			final TextView textview10 = _view.findViewById(R.id.textview10);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final ImageView imageview6 = _view.findViewById(R.id.imageview6);
			final ImageView imageview7 = _view.findViewById(R.id.imageview7);
			final LinearLayout linear19 = _view.findViewById(R.id.linear19);
			final LinearLayout linear20 = _view.findViewById(R.id.linear20);
			final LinearLayout linear21 = _view.findViewById(R.id.linear21);
			final TextView textview9 = _view.findViewById(R.id.textview9);
			final ImageView imageview10 = _view.findViewById(R.id.imageview10);
			final TextView textview8 = _view.findViewById(R.id.textview8);
			final ImageView imageview9 = _view.findViewById(R.id.imageview9);
			final TextView textview7 = _view.findViewById(R.id.textview7);
			final ImageView imageview8 = _view.findViewById(R.id.imageview8);
			
			final VideoView vd = new VideoView(MainActivity.this);
			vd.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT));
			video.addView(vd);
			/*
vd.setVideoURI(Uri.parse(getIntent().getStringExtra("link")));
*/
					
			if (_position == 0) {
				final java.io.File vdF = new java.io.File(getCacheDir(), _data.get((int)_position).get("key1").toString());
				if (!vdF.exists()) {
					try {
						java.io.InputStream vdasset = getAssets().open(_data.get((int)_position).get("key1").toString());
						java.io.FileOutputStream vdFOS = null;
						vdFOS = new java.io.FileOutputStream(vdF);
						final byte[] vdB = new byte[1024];
						int vdS;
						while ((vdS = vdasset.read(vdB)) != -1) {
							vdFOS.write(vdB, 0, vdS);
						}
						vdasset.close();
						vdFOS.close();
					} catch (java.io.IOException e) {
					}
				}
				vd.setVideoPath(vdF.getAbsolutePath());
				
				vd.start();
				
			}
			else {
				final java.io.File vdF = new java.io.File(getCacheDir(), _data.get((int)_position).get("key2").toString());
				if (!vdF.exists()) {
					try {
						java.io.InputStream vdasset = getAssets().open(_data.get((int)_position).get("key2").toString());
						java.io.FileOutputStream vdFOS = null;
						vdFOS = new java.io.FileOutputStream(vdF);
						final byte[] vdB = new byte[1024];
						int vdS;
						while ((vdS = vdasset.read(vdB)) != -1) {
							vdFOS.write(vdB, 0, vdS);
						}
						vdasset.close();
						vdFOS.close();
					} catch (java.io.IOException e) {
					}
				}
				vd.setVideoPath(vdF.getAbsolutePath());
				
				vd.start();
				
			}
			vd.requestFocus();
			/*
vd.start();
*/
				vd.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){
							@Override
							public void onPrepared(MediaPlayer _mediaPlayer){
					
					vd.start();
					
					}
					});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview6Adapter extends RecyclerView.Adapter<Recyclerview6Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview6Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.not, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview2 = _view.findViewById(R.id.circleimageview2);
			final com.vanniktech.emoji.EmojiTextView textview2 = _view.findViewById(R.id.textview2);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			
			if (_position == 0) {
				textview1.setVisibility(View.VISIBLE);
			}
			else {
				textview1.setVisibility(View.GONE);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}