package Facebook.Copy.UI;

import Facebook.Copy.UI.SplashActivity;
import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.io.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.ScrollView;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import androidx.cardview.widget.CardView;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import java.text.DecimalFormat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;

public class MainActivity extends AppCompatActivity {
	
	private ArrayList<HashMap<String, Object>> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> list2 = new ArrayList<>();
	
	private LinearLayout main;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private LinearLayout linear17;
	private LinearLayout linear34;
	private ImageView imageview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private ImageView imageview3;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private ImageView imageview8;
	private LinearLayout linear11;
	private ImageView imageview7;
	private LinearLayout linear12;
	private ImageView imageview9;
	private LinearLayout linear13;
	private ImageView imageview5;
	private LinearLayout linear14;
	private ImageView imageview6;
	private LinearLayout linear15;
	private ImageView imageview4;
	private LinearLayout linear16;
	private ScrollView vscroll1;
	private LinearLayout linear20;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private LinearLayout linear26;
	private LinearLayout linear33;
	private RecyclerView recyclerview2;
	private ImageView imageview10;
	private CardView cardview1;
	private CircleImageView circleimageview1;
	private LinearLayout linear22;
	private TextView textview7;
	private LinearLayout linear35;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private TextView textview2;
	private ImageView imageview12;
	private TextView textview1;
	private ImageView imageview11;
	private TextView textview3;
	private ImageView imageview13;
	private LinearLayout linear27;
	private LinearLayout linear28;
	private LinearLayout linear29;
	private TextView textview6;
	private LinearLayout linear30;
	private TextView textview5;
	private LinearLayout linear32;
	private TextView textview4;
	private LinearLayout linear31;
	private RecyclerView recyclerview3;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		linear17 = findViewById(R.id.linear17);
		linear34 = findViewById(R.id.linear34);
		imageview1 = findViewById(R.id.imageview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		imageview3 = findViewById(R.id.imageview3);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		imageview8 = findViewById(R.id.imageview8);
		linear11 = findViewById(R.id.linear11);
		imageview7 = findViewById(R.id.imageview7);
		linear12 = findViewById(R.id.linear12);
		imageview9 = findViewById(R.id.imageview9);
		linear13 = findViewById(R.id.linear13);
		imageview5 = findViewById(R.id.imageview5);
		linear14 = findViewById(R.id.linear14);
		imageview6 = findViewById(R.id.imageview6);
		linear15 = findViewById(R.id.linear15);
		imageview4 = findViewById(R.id.imageview4);
		linear16 = findViewById(R.id.linear16);
		vscroll1 = findViewById(R.id.vscroll1);
		linear20 = findViewById(R.id.linear20);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		linear26 = findViewById(R.id.linear26);
		linear33 = findViewById(R.id.linear33);
		recyclerview2 = findViewById(R.id.recyclerview2);
		imageview10 = findViewById(R.id.imageview10);
		cardview1 = findViewById(R.id.cardview1);
		circleimageview1 = findViewById(R.id.circleimageview1);
		linear22 = findViewById(R.id.linear22);
		textview7 = findViewById(R.id.textview7);
		linear35 = findViewById(R.id.linear35);
		linear23 = findViewById(R.id.linear23);
		linear24 = findViewById(R.id.linear24);
		linear25 = findViewById(R.id.linear25);
		textview2 = findViewById(R.id.textview2);
		imageview12 = findViewById(R.id.imageview12);
		textview1 = findViewById(R.id.textview1);
		imageview11 = findViewById(R.id.imageview11);
		textview3 = findViewById(R.id.textview3);
		imageview13 = findViewById(R.id.imageview13);
		linear27 = findViewById(R.id.linear27);
		linear28 = findViewById(R.id.linear28);
		linear29 = findViewById(R.id.linear29);
		textview6 = findViewById(R.id.textview6);
		linear30 = findViewById(R.id.linear30);
		textview5 = findViewById(R.id.textview5);
		linear32 = findViewById(R.id.linear32);
		textview4 = findViewById(R.id.textview4);
		linear31 = findViewById(R.id.linear31);
		recyclerview3 = findViewById(R.id.recyclerview3);
	}
	
	private void initializeLogic() {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
			Window w =MainActivity.this.getWindow();
			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(0xFFFFFFFF);
		}
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		cardview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear24.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		linear25.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)50, (int)2, 0xFFE0E0E0, 0xFFFFFFFF));
		imageview1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFF1F2F6));
		imageview2.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFFF1F2F6));
		_removeScollBar(vscroll1);
		for(int _repeat23 = 0; _repeat23 < (int)(20); _repeat23++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "story number".concat(String.valueOf(list.size())));
				list.add(_item);
			}
			
		}
		recyclerview3.setAdapter(new Recyclerview3Adapter(list));
		recyclerview3.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		for(int _repeat28 = 0; _repeat28 < (int)(20); _repeat28++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "story number".concat(String.valueOf(list2.size())));
				list2.add(_item);
			}
			
		}
		recyclerview2.setAdapter(new Recyclerview2Adapter(list2));
		recyclerview2.setLayoutManager(new LinearLayoutManager(this));
	}
	
	public void _removeScollBar(final View _view) {
		_view.setVerticalScrollBarEnabled(false); _view.setHorizontalScrollBarEnabled(false);
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cus_post, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear8 = _view.findViewById(R.id.linear8);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear9 = _view.findViewById(R.id.linear9);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final LinearLayout linear7 = _view.findViewById(R.id.linear7);
			final TextView textview18 = _view.findViewById(R.id.textview18);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final ImageView imageview3 = _view.findViewById(R.id.imageview3);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView textview2 = _view.findViewById(R.id.textview2);
			final LinearLayout linear10 = _view.findViewById(R.id.linear10);
			final LinearLayout linear12 = _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = _view.findViewById(R.id.linear13);
			final LinearLayout linear14 = _view.findViewById(R.id.linear14);
			final LinearLayout linear15 = _view.findViewById(R.id.linear15);
			final LinearLayout linear16 = _view.findViewById(R.id.linear16);
			final LinearLayout linear17 = _view.findViewById(R.id.linear17);
			final LinearLayout linear18 = _view.findViewById(R.id.linear18);
			final TextView textview4 = _view.findViewById(R.id.textview4);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			final TextView textview10 = _view.findViewById(R.id.textview10);
			final TextView textview6 = _view.findViewById(R.id.textview6);
			final TextView textview5 = _view.findViewById(R.id.textview5);
			final ImageView imageview6 = _view.findViewById(R.id.imageview6);
			final ImageView imageview7 = _view.findViewById(R.id.imageview7);
			final LinearLayout linear19 = _view.findViewById(R.id.linear19);
			final LinearLayout linear20 = _view.findViewById(R.id.linear20);
			final LinearLayout linear21 = _view.findViewById(R.id.linear21);
			final TextView textview9 = _view.findViewById(R.id.textview9);
			final ImageView imageview10 = _view.findViewById(R.id.imageview10);
			final TextView textview8 = _view.findViewById(R.id.textview8);
			final ImageView imageview9 = _view.findViewById(R.id.imageview9);
			final TextView textview7 = _view.findViewById(R.id.textview7);
			final ImageView imageview8 = _view.findViewById(R.id.imageview8);
			final LinearLayout linear22 = _view.findViewById(R.id.linear22);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview2 = _view.findViewById(R.id.circleimageview2);
			final LinearLayout linear23 = _view.findViewById(R.id.linear23);
			final LinearLayout linear24 = _view.findViewById(R.id.linear24);
			final LinearLayout linear25 = _view.findViewById(R.id.linear25);
			final TextView textview12 = _view.findViewById(R.id.textview12);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final TextView textview11 = _view.findViewById(R.id.textview11);
			final ImageView imageview11 = _view.findViewById(R.id.imageview11);
			final TextView textview16 = _view.findViewById(R.id.textview16);
			final LinearLayout linear27 = _view.findViewById(R.id.linear27);
			final TextView textview15 = _view.findViewById(R.id.textview15);
			final TextView textview13 = _view.findViewById(R.id.textview13);
			final TextView textview14 = _view.findViewById(R.id.textview14);
			final LinearLayout linear26 = _view.findViewById(R.id.linear26);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview3 = _view.findViewById(R.id.circleimageview3);
			final ImageView imageview15 = _view.findViewById(R.id.imageview15);
			final ImageView imageview14 = _view.findViewById(R.id.imageview14);
			final ImageView imageview13 = _view.findViewById(R.id.imageview13);
			final TextView textview17 = _view.findViewById(R.id.textview17);
			
			linear23.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF1F2F6));
			linear26.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)50, 0xFFF1F2F6));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class Recyclerview3Adapter extends RecyclerView.Adapter<Recyclerview3Adapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Recyclerview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cus_story, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView your_story = _view.findViewById(R.id.your_story);
			final androidx.cardview.widget.CardView other_story = _view.findViewById(R.id.other_story);
			final RelativeLayout s1 = _view.findViewById(R.id.s1);
			final ImageView imageview4 = _view.findViewById(R.id.imageview4);
			final ImageView add = _view.findViewById(R.id.add);
			final LinearLayout linear51 = _view.findViewById(R.id.linear51);
			final TextView textview28 = _view.findViewById(R.id.textview28);
			final RelativeLayout s2 = _view.findViewById(R.id.s2);
			final ImageView imageview5 = _view.findViewById(R.id.imageview5);
			final de.hdodenhof.circleimageview.CircleImageView c1 = _view.findViewById(R.id.c1);
			final LinearLayout linear52 = _view.findViewById(R.id.linear52);
			final TextView textview29 = _view.findViewById(R.id.textview29);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			if (_position == 0) {
				your_story.setVisibility(View.VISIBLE);
				other_story.setVisibility(View.GONE);
			}
			else {
				your_story.setVisibility(View.GONE);
				other_story.setVisibility(View.VISIBLE);
			}
			add.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)100, 0xFF1877F2));
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}